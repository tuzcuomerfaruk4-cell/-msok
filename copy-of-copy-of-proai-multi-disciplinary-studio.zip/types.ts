
export enum AIRole {
  MASTER = 'NEON Full-Stack (Python + Web)',
  COPYWRITER = 'İçerik Yazarı & Pythonic Copywriter',
  DESIGNER = 'Görsel Tasarımcı & AI Image Expert',
  DEVELOPER = 'Python & Web Geliştirici (PyCore Focus)',
  NOCODE = 'No-code / Low-code & Automation Uzmanı',
  MARKETER = 'Dijital Pazarlama & Veri Analitiği',
  SEO = 'SEO & Algoritmik Growth Hacker',
  STRATEGIST = 'İş Analisti (Python Data Analysis)',
  EDUCATOR = 'Eğitmen & Teknik Mentör',
  EDITOR = 'Doküman & Rapor Editörü',
  LOCAL_EXPERT = 'Harita & Coğrafi Veri Uzmanı'
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}

export interface DebugLog {
  timestamp: string;
  module: string;
  message: string;
  type: 'info' | 'warn' | 'error' | 'success';
}

export interface GenerationRequest {
  role: AIRole;
  context: string;
  audience: string;
  tone: string;
  isOptimizationEnabled?: boolean;
  isDebugEnabled?: boolean;
  isAutoModeEnabled?: boolean;
  history?: Message[];
}

export interface GroundingChunk {
  web?: { uri: string; title: string };
  maps?: { uri: string; title: string };
}

export interface GenerationResponse {
  content: string;
  imageUrl?: string;
  groundingChunks?: GroundingChunk[];
  functionCalls?: any[];
}
