
import React, { useRef, useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import ContentDisplay from './components/ContentDisplay';
import { generateProfessionalContent, connectToLiveVoice, decodeAudio, decodeAudioData, encodeAudio } from './services/geminiService';
import { AIRole, GenerationRequest, Message, GroundingChunk, DebugLog } from './types';

const App: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{content: string, imageUrl?: string, groundingChunks?: GroundingChunk[], iotActions?: string[]} | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<Message[]>([]);
  const [hasKey, setHasKey] = useState<boolean | null>(null);
  
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isDebugEnabled, setIsDebugEnabled] = useState(false);
  const [isAutoModeEnabled, setIsAutoModeEnabled] = useState(false);
  const [debugLogs, setDebugLogs] = useState<DebugLog[]>([]);
  const [transcriptions, setTranscriptions] = useState<{ text: string, isUser: boolean }[]>([]);
  const [iotLogs, setIotLogs] = useState<string[]>([]);
  
  const liveSessionPromiseRef = useRef<Promise<any> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);

  useEffect(() => {
    const savedHistory = localStorage.getItem('neon_history');
    const savedIotLogs = localStorage.getItem('neon_iot_logs');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
    if (savedIotLogs) setIotLogs(JSON.parse(savedIotLogs));

    const checkKey = async () => {
      try {
        const selected = await (window as any).aistudio.hasSelectedApiKey();
        setHasKey(selected);
      } catch (e) {
        console.error("PyCore Auth Error", e);
      }
    };
    checkKey();
  }, []);

  useEffect(() => {
    localStorage.setItem('neon_history', JSON.stringify(history));
    localStorage.setItem('neon_iot_logs', JSON.stringify(iotLogs));
  }, [history, iotLogs]);

  const addDebugLog = (module: string, message: string, type: 'info' | 'warn' | 'error' | 'success' = 'info') => {
    const log: DebugLog = {
      timestamp: new Date().toLocaleTimeString(),
      module,
      message,
      type
    };
    setDebugLogs(prev => [...prev, log]);
  };

  const handleClearCache = () => {
    localStorage.removeItem('neon_history');
    localStorage.removeItem('neon_iot_logs');
    setHistory([]);
    setIotLogs([]);
    setResult(null);
    addDebugLog("SYSTEM", "Yerel bellek sıfırlandı.", "warn");
  };

  const handleOpenKeyDialog = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true);
  };

  const executeIotAction = async (fc: any) => {
    const { deviceName, action, value } = fc.args;
    const log = `PyAuto: ${deviceName} -> ${action} OK.`;
    setIotLogs(prev => [log, ...prev].slice(0, 10));
    if (isDebugEnabled) addDebugLog("EXEC", `${deviceName} tetiklendi.`, "success");
    return "OK";
  };

  const handleGenerate = async (req: GenerationRequest & { style?: string }) => {
    if (hasKey === false) await handleOpenKeyDialog();
    
    setLoading(true);
    setError(null);
    if (!req.isAutoModeEnabled) setDebugLogs([]);
    
    try {
      if (isDebugEnabled) addDebugLog("CORE", "Sentez motoru ateşlendi, işlem başladı...", "info");
      
      const payload = { ...req, history };
      const data: any = await generateProfessionalContent(payload);
      
      const actions: string[] = [];
      if (data.functionCalls && data.functionCalls.length > 0) {
        for (const fc of data.functionCalls) {
          if (fc.name === 'controlHomeDevice') {
            await executeIotAction(fc);
            actions.push(`${fc.args.deviceName}: ${fc.args.action}`);
          }
        }
      }
      
      setResult({ ...data, iotActions: actions });
      const newHistory: Message[] = [...history, { role: 'user', text: req.context }, { role: 'model', text: data.content.substring(0, 500) }];
      setHistory(newHistory.slice(-20));
      
      if (isDebugEnabled) addDebugLog("CORE", "Veri sentezi başarıyla tamamlandı.", "success");
      if (!isDebugEnabled) window.scrollTo({ top: 0, behavior: 'smooth' });

      if (isAutoModeEnabled && !req.context.includes("[AUTONOMOUS_REFINE]")) {
        setTimeout(() => {
          handleGenerate({
            ...req,
            context: `[AUTONOMOUS_REFINE]: Sonuçları yerel verimlilik açısından analiz et.`,
            isAutoModeEnabled: true
          });
        }, 1500); // Otonom geçişi hızlandırıldı
      }
    } catch (err: any) {
      const msg = err.message || "Motor hatası.";
      setError(msg);
      if (isDebugEnabled) addDebugLog("ERR", msg, "error");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleVoice = async () => {
    if (isVoiceActive) {
      if (liveSessionPromiseRef.current) liveSessionPromiseRef.current.then(session => session.close());
      setIsVoiceActive(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });

      const sessionPromise = connectToLiveVoice({
        onAudioChunk: async (base64) => {
          if (!audioContextRef.current) return;
          const bytes = decodeAudio(base64);
          const buffer = await decodeAudioData(bytes, audioContextRef.current, 24000, 1);
          const source = audioContextRef.current.createBufferSource();
          source.buffer = buffer;
          source.connect(audioContextRef.current.destination);
          nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioContextRef.current.currentTime);
          source.start(nextStartTimeRef.current);
          nextStartTimeRef.current += buffer.duration;
        },
        onInterrupted: () => { nextStartTimeRef.current = 0; },
        onTranscription: (text, isUser) => { setTranscriptions(prev => [...prev, { text, isUser }].slice(-10)); },
        onFunctionCall: async (fc) => fc.name === 'controlHomeDevice' ? await executeIotAction(fc) : "UNKNOWN"
      });
      liveSessionPromiseRef.current = sessionPromise;
      const source = inputCtx.createMediaStreamSource(stream);
      const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
      scriptProcessor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const int16 = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
        const pcmBase64 = encodeAudio(new Uint8Array(int16.buffer));
        sessionPromise.then(session => session.sendRealtimeInput({ media: { data: pcmBase64, mimeType: 'audio/pcm;rate=16000' } }));
      };
      source.connect(scriptProcessor);
      scriptProcessor.connect(inputCtx.destination);
      setIsVoiceActive(true);
    } catch (e) { setError("Ses başlatılamadı."); }
  };

  if (hasKey === false) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <div className="bg-slate-900 p-12 rounded-[4rem] border-2 border-indigo-500/30 shadow-2xl max-w-xl">
           <i className="fab fa-python text-6xl text-indigo-500 mb-8 animate-pulse"></i>
           <h1 className="text-3xl font-black text-white mb-4 italic uppercase">Yerel İstasyon Bağlantısı</h1>
           <p className="text-slate-400 mb-10 text-sm">Sistemi yerelde çalıştırmak için bir API anahtarı gerekiyor, Patron.</p>
           <button onClick={handleOpenKeyDialog} className="w-full py-5 bg-indigo-600 text-white rounded-3xl font-black uppercase tracking-widest hover:bg-indigo-500 transition-all">ANAHTARI SEÇ VE BAŞLAT</button>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen flex flex-col lg:flex-row antialiased transition-colors duration-500 ${isAutoModeEnabled ? 'bg-indigo-50/20' : 'bg-slate-50'}`}>
      <Sidebar 
        onGenerate={handleGenerate} 
        onToggleVoice={handleToggleVoice} 
        isVoiceActive={isVoiceActive} 
        loading={loading} 
        historyLength={history.length/2} 
        iotLogs={iotLogs}
        isDebugEnabled={isDebugEnabled}
        setIsDebugEnabled={setIsDebugEnabled}
        isAutoModeEnabled={isAutoModeEnabled}
        setIsAutoModeEnabled={setIsAutoModeEnabled}
        onClearCache={handleClearCache}
      />
      <main className="flex-1 flex flex-col min-h-screen relative overflow-y-hidden bg-white">
        {error && (
          <div className="fixed top-8 right-8 z-[100] bg-red-600 text-white p-6 rounded-[2rem] shadow-2xl flex items-center gap-4 max-w-md animate-in slide-in-from-right">
            <i className="fas fa-exclamation-circle text-2xl"></i>
            <div className="flex-1">
              <p className="font-bold text-sm leading-tight">{error}</p>
            </div>
            <button onClick={() => setError(null)} className="p-2 hover:bg-white/10 rounded-full"><i className="fas fa-times"></i></button>
          </div>
        )}
        <ContentDisplay 
          content={result?.content || ''} 
          imageUrl={result?.imageUrl} 
          groundingChunks={result?.groundingChunks} 
          loading={loading} 
          transcriptions={transcriptions} 
          iotActions={result?.iotActions}
          debugLogs={debugLogs}
          isDebugEnabled={isDebugEnabled}
        />
        <footer className="p-8 text-center bg-white border-t border-slate-100 text-[9px] font-black uppercase tracking-[0.3em] text-slate-400">
          NEON LOCAL STATION // HOST: 127.0.0.1 // {new Date().toLocaleTimeString()}
        </footer>
      </main>
    </div>
  );
};

export default App;
