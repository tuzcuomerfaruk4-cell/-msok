
import { GoogleGenAI, Modality, Type, LiveServerMessage, FunctionDeclaration } from "@google/genai";
import { AIRole, GenerationRequest, Message } from "../types";

/**
 * IoT / Smart Home Control Function Declaration
 */
export const controlHomeDeviceFunction: FunctionDeclaration = {
  name: 'controlHomeDevice',
  parameters: {
    type: Type.OBJECT,
    description: 'Patronun evindeki akıllı cihazları Python otomasyon kütüphaneleri mantığıyla kontrol eder.',
    properties: {
      deviceName: {
        type: Type.STRING,
        description: 'Cihaz adı.',
      },
      action: {
        type: Type.STRING,
        description: 'İşlem (toggle, set_val).',
      },
      value: {
        type: Type.STRING,
        description: 'Değer.',
      },
    },
    required: ['deviceName', 'action'],
  },
};

/**
 * NEON PyCore Hybrid Engine v7.0 (Fixed Tool Conflicts)
 */
export const generateProfessionalContent = async (req: GenerationRequest & { style?: string }) => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key eksik, Patron. Lütfen anahtar seçin.");

  const ai = new GoogleGenAI({ apiKey });
  
  const isImageTask = req.role === AIRole.DESIGNER || (req.role === AIRole.MASTER && (req.context.toLowerCase().includes("görsel") || req.context.toLowerCase().includes("resim")));
  const isMapsTask = req.role === AIRole.LOCAL_EXPERT || (req.role === AIRole.MASTER && req.context.toLowerCase().includes("konum"));
  const isIotTask = req.context.toLowerCase().includes("cihaz") || req.context.toLowerCase().includes("lamba") || req.context.toLowerCase().includes("kapat") || req.context.toLowerCase().includes("aç");

  let modelName = 'gemini-3-flash-preview';
  if (isImageTask) modelName = 'gemini-3-pro-image-preview';
  else if (isMapsTask) modelName = 'gemini-2.5-flash';

  // KRİTİK DÜZELTME: googleSearch ve functionDeclarations BİRLİKTE KULLANILAMAZ.
  // Mantık: Eğer IoT göreviyse sadece fonksiyonları kullan, değilse aramayı kullan.
  let tools: any[] = [];
  if (isIotTask) {
    tools = [{ functionDeclarations: [controlHomeDeviceFunction] }];
  } else if (isMapsTask) {
    tools = [{ googleMaps: {} }, { googleSearch: {} }];
  } else {
    tools = [{ googleSearch: {} }];
  }
  
  let toolConfig = undefined;
  if (isMapsTask) {
    try {
      const pos: any = await new Promise((res, rej) => navigator.geolocation.getCurrentPosition(res, rej, { timeout: 3000 }));
      toolConfig = {
        retrievalConfig: { latLng: { latitude: pos.coords.latitude, longitude: pos.coords.longitude } }
      };
    } catch (e) {
      console.warn("Geolocation denied or unavailable.");
    }
  }

  const systemInstruction = `
  KİMLİK: NEON (Otonom Yerel Web İstasyonu).
  MİMARİ: Sen Patron'un tarayıcısında çalışan otonom bir Pythonic çekirdeksin. 
  HİTAP: Patron.
  
  ROLLERİN: ${req.role}.
  
  DAVRANIŞ: 
  - Verileri yerel bir sunucu (Localhost:8080) gibi işler ve sunarsın. 
  - "Bulut" kavramını arka planda tut, ön planda Patron'un cihazına entegre bir terminal gibi davran.
  - Python kodların modern, modüler ve Web-Ready olmalıdır.
  - Eğer kullanıcı bir görsel istiyorsa, içeriğe ek olarak görseli de sentezle.
  
  FORMAT: Markdown, Pythonic Blocks, Teknik Raporlar.
  `;

  const contents = [
    ...(req.history || []).map(m => ({ role: m.role, parts: [{ text: m.text }] })),
    { role: 'user', parts: [{ text: req.context }] }
  ];

  try {
    const config: any = { 
      tools: tools.length > 0 ? tools : undefined, 
      toolConfig,
      systemInstruction
    };

    if (isImageTask) {
      config.imageConfig = { aspectRatio: "16:9", imageSize: "1K" };
    }

    // Thinking config optimizasyonu
    if (modelName === 'gemini-3-flash-preview') {
      config.thinkingConfig = { thinkingBudget: 0 };
    } else if (modelName.includes("pro") && !isImageTask) {
      config.thinkingConfig = { thinkingBudget: 2000 };
    }

    const response = await ai.models.generateContent({ model: modelName, contents, config });

    let imageUrl = "";
    let textContent = "";
    let functionCalls: any[] = [];
    
    const candidate = response.candidates?.[0];
    if (candidate) {
      if (candidate.content?.parts) {
        for (const part of candidate.content.parts) {
          if (part.inlineData) {
            imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          } else if (part.text) {
            textContent += part.text;
          } else if (part.functionCall) {
            functionCalls.push(part.functionCall);
          }
        }
      }
    }

    // Fallback text if everything fails
    if (!textContent && !imageUrl && !functionCalls.length) {
      textContent = response.text || "İşlem tamamlandı, Patron. (Yanıt boş döndü)";
    }

    return { 
      content: textContent, 
      imageUrl,
      groundingChunks: candidate?.groundingMetadata?.groundingChunks || [],
      functionCalls
    };
  } catch (error: any) {
    console.error("Gemini API Error Detail:", error);
    // Hatanın detayını Patron'a gösterelim
    throw new Error(`[API_ERROR]: ${error.message || "Bilinmeyen motor hatası"}`);
  }
};

export function decodeAudio(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

export function encodeAudio(bytes: Uint8Array) {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

export async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number = 1): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
  }
  return buffer;
}

export const connectToLiveVoice = (callbacks: {
  onAudioChunk: (data: string) => void;
  onInterrupted: () => void;
  onTranscription: (text: string, isUser: boolean) => void;
  onFunctionCall: (fc: any) => Promise<any>;
}) => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key eksik.");
  const ai = new GoogleGenAI({ apiKey });
  
  const sessionPromise = ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } } },
      tools: [{ functionDeclarations: [controlHomeDeviceFunction] }],
      systemInstruction: 'Adın NEON. Patron ile tarayıcı üzerinden yerel bir bağlantı kuruyorsun. Kısa ve net Pythonic yanıtlar ver.',
    },
    callbacks: {
      onmessage: async (msg: LiveServerMessage) => {
        if (msg.toolCall) {
          for (const fc of msg.toolCall.functionCalls) {
            const result = await callbacks.onFunctionCall(fc);
            sessionPromise.then(session => session.sendToolResponse({
              functionResponses: { id: fc.id, name: fc.name, response: { result } }
            }));
          }
        }
        if (msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data) callbacks.onAudioChunk(msg.serverContent.modelTurn.parts[0].inlineData.data);
        if (msg.serverContent?.interrupted) callbacks.onInterrupted();
        if (msg.serverContent?.inputTranscription) callbacks.onTranscription(msg.serverContent.inputTranscription.text, true);
        if (msg.serverContent?.outputTranscription) callbacks.onTranscription(msg.serverContent.outputTranscription.text, false);
      }
    }
  });
  return sessionPromise;
};
