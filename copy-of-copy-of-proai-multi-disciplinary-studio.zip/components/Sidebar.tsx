
import React, { useState, useEffect } from 'react';
import { AIRole } from '../types';

interface SidebarProps {
  onGenerate: (data: { context: string, audience: string, tone: string, role: AIRole, style?: string, isOptimizationEnabled: boolean, isDebugEnabled: boolean, isAutoModeEnabled: boolean }) => void;
  onToggleVoice: () => void;
  isVoiceActive: boolean;
  loading: boolean;
  historyLength: number;
  iotLogs?: string[];
  isDebugEnabled: boolean;
  setIsDebugEnabled: (val: boolean) => void;
  isAutoModeEnabled: boolean;
  setIsAutoModeEnabled: (val: boolean) => void;
  onClearCache: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  onGenerate, 
  onToggleVoice, 
  isVoiceActive, 
  loading, 
  historyLength, 
  iotLogs,
  isDebugEnabled,
  setIsDebugEnabled,
  isAutoModeEnabled,
  setIsAutoModeEnabled,
  onClearCache
}) => {
  const [context, setContext] = useState('');
  const [audience, setAudience] = useState('');
  const [tone, setTone] = useState('Pythonic & Veri Odaklı');
  const [role, setRole] = useState<AIRole>(AIRole.MASTER);
  const [uptime, setUptime] = useState('00:00:00');

  useEffect(() => {
    const start = Date.now();
    const interval = setInterval(() => {
      const diff = Date.now() - start;
      const h = Math.floor(diff / 3600000).toString().padStart(2, '0');
      const m = Math.floor((diff % 3600000) / 60000).toString().padStart(2, '0');
      const s = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
      setUptime(`${h}:${m}:${s}`);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!context) return;
    onGenerate({ 
      context, 
      audience: audience || "Local Environment", 
      tone, 
      role, 
      isOptimizationEnabled: true,
      isDebugEnabled,
      isAutoModeEnabled
    });
  };

  return (
    <aside className="w-full lg:w-[460px] bg-slate-950 text-slate-300 h-screen sticky top-0 p-8 flex flex-col gap-8 overflow-y-auto z-30 border-r border-indigo-500/20 shadow-2xl no-print">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-5">
          <div className="bg-indigo-600 w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-xl rotate-[-3deg]">
            <i className="fab fa-python text-2xl"></i>
          </div>
          <div>
            <h1 className="text-2xl font-black text-white italic tracking-tighter">NEON LOCAL</h1>
            <p className="text-[9px] uppercase tracking-[0.3em] text-slate-500 font-bold mt-1">Web Integrated Engine</p>
          </div>
        </div>
        <div className="text-right">
           <span className="text-[10px] font-mono text-indigo-400 font-black block">SYS_UP: {uptime}</span>
           <span className="text-[9px] text-slate-600 font-bold">MEM: {historyLength} STACKS</span>
        </div>
      </div>

      <div className="space-y-3">
        <div className="bg-slate-900/50 p-5 rounded-[2rem] border border-white/5 flex items-center justify-between">
          <div className="flex flex-col"><span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Debug</span></div>
          <button onClick={() => setIsDebugEnabled(!isDebugEnabled)} className={`w-12 h-6 rounded-full relative transition-all ${isDebugEnabled ? 'bg-indigo-600' : 'bg-slate-800'}`}>
            <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${isDebugEnabled ? 'left-7' : 'left-1'}`}></div>
          </button>
        </div>

        <div className="bg-slate-900/50 p-5 rounded-[2rem] border border-white/5 flex items-center justify-between">
          <div className="flex flex-col"><span className="text-[10px] font-black text-cyan-400 uppercase tracking-widest">Otonom</span></div>
          <button onClick={() => setIsAutoModeEnabled(!isAutoModeEnabled)} className={`w-12 h-6 rounded-full relative transition-all ${isAutoModeEnabled ? 'bg-cyan-600' : 'bg-slate-800'}`}>
            <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${isAutoModeEnabled ? 'left-7' : 'left-1'}`}></div>
          </button>
        </div>

        <button 
          onClick={onClearCache}
          className="w-full py-4 bg-slate-900 text-slate-500 hover:text-red-400 border border-white/5 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all"
        >
          <i className="fas fa-trash-alt mr-3"></i> Yerel Belleği Temizle
        </button>
      </div>

      <div className="bg-black/40 p-5 rounded-[2rem] border border-white/5">
        <div className="flex items-center gap-3 mb-3">
          <i className="fas fa-microchip text-indigo-500 text-xs"></i>
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Local Node Feed</span>
        </div>
        <div className="space-y-1 font-mono text-[8px] text-slate-600 h-24 overflow-y-auto">
          {iotLogs && iotLogs.map((log, i) => <p key={i} className="border-b border-white/5 pb-1">[{new Date().toLocaleTimeString()}] > {log}</p>)}
        </div>
      </div>

      <div className={`p-1 rounded-[2.5rem] border transition-all ${isVoiceActive ? 'bg-indigo-600 border-indigo-400' : 'bg-slate-900 border-white/5'}`}>
        <button onClick={onToggleVoice} className={`w-full py-5 rounded-[2.3rem] flex items-center justify-center gap-4 transition-all ${isVoiceActive ? 'bg-white text-indigo-600 font-black' : 'bg-transparent text-slate-500 font-bold'}`}>
          <i className={`fas ${isVoiceActive ? 'fa-volume-up animate-pulse' : 'fa-microphone-alt'} text-xl`}></i>
          <span className="text-[10px] uppercase tracking-widest">{isVoiceActive ? 'SESLİ_AKTİF' : 'SESLİ_KOMUT'}</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        <div className="space-y-3">
          <textarea 
            required
            value={context}
            onChange={(e) => setContext(e.target.value)}
            className="w-full h-48 bg-slate-900 border-2 border-white/5 rounded-[2.5rem] px-8 py-6 text-sm text-white outline-none focus:border-indigo-600 transition-all resize-none placeholder:text-slate-700 italic"
            placeholder="Bir yerel işlem emri girin..."
          />
        </div>

        <button 
          disabled={loading}
          type="submit"
          className={`w-full py-6 rounded-[2.5rem] font-black text-[11px] uppercase tracking-[0.3em] text-white shadow-xl transition-all ${loading ? 'bg-slate-800 animate-pulse' : 'bg-indigo-600 hover:bg-indigo-500'}`}
        >
          {loading ? 'SENTEZLENİYOR...' : 'YERELE SENTEZLE'}
        </button>
      </form>
    </aside>
  );
};

export default Sidebar;
