
import React from 'react';
import ReactMarkdown from 'react-markdown';
import { GroundingChunk, DebugLog } from '../types';

interface ContentDisplayProps {
  content: string;
  imageUrl?: string;
  groundingChunks?: GroundingChunk[];
  loading: boolean;
  transcriptions?: { text: string, isUser: boolean }[];
  iotActions?: string[];
  debugLogs?: DebugLog[];
  isDebugEnabled: boolean;
}

const ContentDisplay: React.FC<ContentDisplayProps> = ({ 
  content, 
  imageUrl, 
  groundingChunks, 
  loading, 
  transcriptions, 
  iotActions,
  debugLogs,
  isDebugEnabled
}) => {
  if (loading && !isDebugEnabled) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-12 bg-white">
        <div className="relative w-24 h-24 mb-10">
          <div className="absolute inset-0 border-[6px] border-slate-100 rounded-full"></div>
          <div className="absolute inset-0 border-[6px] border-t-indigo-600 rounded-full animate-spin"></div>
        </div>
        <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase italic animate-pulse">Analiz Devam Ediyor</h3>
        <p className="text-slate-400 font-black uppercase tracking-[0.2em] text-[10px] mt-4">Veriler yerel çekirdekte işleniyor, Patron.</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-white scroll-smooth flex flex-col">
      <div className="flex-1 p-8 lg:p-24">
        <div className="max-w-6xl mx-auto space-y-20">
          
          {loading && isDebugEnabled && debugLogs && (
            <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md p-10 lg:p-24 flex flex-col">
               <div className="flex items-center justify-between mb-8 border-b border-white/10 pb-6">
                 <div className="flex items-center gap-4">
                   <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
                     <i className="fas fa-terminal text-white"></i>
                   </div>
                   <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Sistem Analizi</h2>
                 </div>
                 <span className="text-indigo-400 font-mono text-xs tracking-widest uppercase animate-pulse">[CANLI_IZLEME]</span>
               </div>
               <div className="flex-1 bg-black/50 rounded-[2rem] border border-white/10 p-8 font-mono text-base overflow-y-auto space-y-3 custom-scrollbar">
                  {debugLogs.map((log, i) => (
                    <div key={i} className="flex gap-4 animate-in slide-in-from-left duration-200">
                      <span className="text-slate-600 shrink-0">[{log.timestamp}]</span>
                      <span className={`font-bold uppercase w-24 shrink-0 
                        ${log.type === 'success' ? 'text-green-500' : 'text-indigo-400'}
                        ${log.type === 'error' ? 'text-red-500' : ''}
                      `}>{log.module}:</span>
                      <span className="text-slate-300">{log.message}</span>
                    </div>
                  ))}
               </div>
            </div>
          )}

          {(!content && !imageUrl && !loading) && (
            <div className="flex flex-col items-center justify-center py-40 text-center">
              <div className="w-32 h-32 bg-slate-50 rounded-[3rem] flex items-center justify-center mb-10">
                <i className="fab fa-python text-6xl text-slate-200"></i>
              </div>
              <h3 className="text-3xl font-black text-slate-300 uppercase italic">Sistem Beklemede</h3>
              <p className="text-slate-400 text-[9px] font-black uppercase tracking-[0.4em] mt-2">Patron, bir emir vermenizi bekliyorum.</p>
            </div>
          )}

          {iotActions && iotActions.length > 0 && (
            <div className="bg-slate-950 text-indigo-400 p-10 rounded-[3rem] shadow-xl border border-white/5">
              <div className="flex items-center gap-4 mb-8">
                 <i className="fas fa-bolt text-yellow-400"></i>
                 <h4 className="text-[11px] font-black uppercase tracking-widest italic">Otomasyon Durumu</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {iotActions.map((action, idx) => (
                  <div key={idx} className="bg-white/5 p-5 rounded-2xl border border-white/5 flex items-center justify-between">
                    <span className="text-xs font-mono">{action}</span>
                    <span className="text-[9px] font-black text-green-500 uppercase tracking-widest italic">Tetiklendi</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {(content || imageUrl) && (
            <div className="flex flex-wrap gap-6 justify-between items-center bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100 no-print sticky top-6 z-40 backdrop-blur-xl bg-white/90">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-white">
                  <i className="fab fa-python text-xl"></i>
                </div>
                <div>
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Sentez Tamamlandı</span>
                  <span className="text-lg font-black text-slate-900 uppercase italic leading-none">İşlem Sonucu</span>
                </div>
              </div>
              <button 
                onClick={() => window.print()}
                className="px-10 py-4 rounded-full bg-slate-950 text-white text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-lg"
              >
                RAPORU ÇIKART
              </button>
            </div>
          )}

          {imageUrl && (
            <div className="rounded-[4rem] overflow-hidden shadow-2xl border-[12px] border-white group relative">
              <img src={imageUrl} alt="NEON Asset" className="w-full h-auto object-cover" />
            </div>
          )}

          {content && (
            <div className="bg-white p-10 lg:p-24 rounded-[4rem] shadow-sm border border-slate-50 prose prose-slate max-w-none">
              <ReactMarkdown
                components={{
                  h1: ({node, ...props}) => <h1 className="text-6xl font-black text-slate-900 mb-12 italic uppercase leading-tight" {...props} />,
                  h2: ({node, ...props}) => <h2 className="text-2xl font-black mt-20 mb-10 py-5 px-8 bg-slate-900 text-white rounded-2xl italic uppercase" {...props} />,
                  p: ({node, ...props}) => <p className="leading-relaxed mb-10 text-xl text-slate-600 font-medium" {...props} />,
                  code: ({node, inline, children, ...props}: any) => (
                    !inline ? (
                      <div className="my-12 rounded-3xl overflow-hidden border-2 border-slate-900 shadow-xl">
                        <div className="bg-slate-900 px-6 py-3 flex justify-between items-center">
                           <span className="text-indigo-400 text-[10px] font-black uppercase tracking-widest">Pythonic Code</span>
                        </div>
                        <pre className="p-10 bg-[#020617] text-indigo-200 text-xl font-mono overflow-x-auto">{children}</pre>
                      </div>
                    ) : <code className="bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-lg font-bold" {...props}>{children}</code>
                  )
                }}
              >
                {content}
              </ReactMarkdown>
            </div>
          )}

          {transcriptions && transcriptions.length > 0 && (
            <div className="bg-slate-900 p-12 rounded-[4rem] no-print shadow-xl">
              <div className="flex flex-col gap-6 max-w-3xl mx-auto">
                {transcriptions.map((t, i) => (
                  <div key={i} className={`p-6 rounded-[2rem] text-lg font-bold ${t.isUser ? 'bg-white text-slate-800 self-end' : 'bg-indigo-600 text-white self-start italic'}`}>
                    {t.text}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContentDisplay;
